package com.mayank.ppg.database;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mayank.ppg.view.PpgErrorDialog;

public class SqliteConnector {

	public static Connection dbConnect() {
	 try {
		Class.forName("org.sqlite.JDBC");
		Connection connection = DriverManager.getConnection("jdbc:sqlite:D:\\marsWorkspace\\Ppg plotter\\bin\\Resources\\database\\ppgData.db");
		return connection;
	 }catch(Exception exp) {
		new PpgErrorDialog("Unable to connect with the database",null);
	 }
		return null;
	}
	
}
