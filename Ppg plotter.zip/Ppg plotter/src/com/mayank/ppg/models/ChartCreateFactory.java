package com.mayank.ppg.models;

import com.mayank.ppg.enumrations.Charts;

import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.BubbleChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.Chart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;

public class ChartCreateFactory {

	
	
	public static Chart createChart(int lowerBound,int upperBound,Charts chart) {
		switch(chart) {
		case lineChart:
			return createLineChart(lowerBound,upperBound);
		case pieChart:
			return createPieChart();
		case areaChart:
			return createAreaChart(lowerBound,upperBound);
		case barChart:
			return createBarChart(lowerBound,upperBound);
		case bubbleChart:
			return createBubbleChart(lowerBound,upperBound);
		}
		return null;
	}
	
	private static LineChart createLineChart(int lowerBoundint,int upperBoundint) {
		NumberAxis xAxis = new NumberAxis(lowerBoundint,upperBoundint,1);
		NumberAxis yAxis = new NumberAxis(lowerBoundint,upperBoundint,1);
		LineChart<Number,Number> lc = new LineChart<Number,Number>(xAxis,yAxis);	
		return lc;
	}
	
	private static AreaChart createAreaChart(int lowerBoundint,int upperBoundint) {
		NumberAxis xAxis = new NumberAxis(lowerBoundint,upperBoundint,1);
		NumberAxis yAxis = new NumberAxis(lowerBoundint,upperBoundint,1);
		AreaChart<Number,Number> ac = new AreaChart<Number,Number>(xAxis,yAxis);	
		return ac;
	}
	
	private static BubbleChart createBubbleChart(int lowerBoundint,int upperBoundint) {
		NumberAxis xAxis = new NumberAxis(lowerBoundint,upperBoundint,1);
		NumberAxis yAxis = new NumberAxis(lowerBoundint,upperBoundint,1);
		BubbleChart<Number,Number> bc = new BubbleChart<Number,Number>(xAxis,yAxis);	
		return bc;
	}
	
	private static BarChart createBarChart(int lowerBoundint,int upperBoundint) {
		CategoryAxis xAxis = new CategoryAxis();
		NumberAxis yAxis = new NumberAxis(lowerBoundint,upperBoundint,1);
		BarChart<String,Number> bc = new BarChart(xAxis,yAxis);
		return bc;
	}
	
	private static PieChart createPieChart() {
	return new PieChart();
	}
}
