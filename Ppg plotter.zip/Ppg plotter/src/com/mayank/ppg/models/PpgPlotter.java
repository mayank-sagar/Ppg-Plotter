package com.mayank.ppg.models;

import java.util.Collections;
import java.util.List;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;

public class PpgPlotter {
private ObjectProperty<Menu> actionsMenu;
private ObjectProperty<Menu> chartsMenu;
private IntegerProperty chartSelected;

public PpgPlotter() {
	setActionsMenu(new Menu("Actions"));
	setChartsMenu(new Menu("Charts"));
	addMenuItemsAndUserData();
}

private void addMenuItemsAndUserData() {
	addActionsMenuItems();
	addChartsMenuItems();
	addActionsMenuItemsUserData();
	addChartsMenuItemsUserData();
}


public IntegerProperty chartSelectedProperty() {
	if(chartSelected == null) 
		chartSelected = new SimpleIntegerProperty();
	return chartSelected;
}

public void setChartSelected(int i) {
	chartSelectedProperty().set(i);
} 

public int getChartSelected() {
return chartSelected == null?null:chartSelectedProperty().get();
}

public ObjectProperty<Menu> actionsMenuProperty() {
	if(actionsMenu == null) {
		actionsMenu = new SimpleObjectProperty<Menu>();
	}
	return actionsMenu;
}

public void setActionsMenu(Menu menu) {
	actionsMenuProperty().set(menu);
}

public Menu getActionsMenu() {
	return actionsMenu == null?null:actionsMenu.get();
}

public ObjectProperty<Menu> chartsMenuProperty() {
	if(chartsMenu == null) {
		chartsMenu = new SimpleObjectProperty<Menu>();
	}
	return chartsMenu;
}

public void setChartsMenu(Menu menu) {
	chartsMenuProperty().set(menu);
}


public Menu getChartsMenu() {
	return chartsMenu == null?null:chartsMenu.get();
}

private void addActionsMenuItems() {
	addMenuItems(actionsMenu.get().menuItemsProperty().get(),"New plot","Import ppg","Save to database","extract from database");
}

private void addChartsMenuItems() {
	addMenuItems(chartsMenu.get().menuItemsProperty().get(),
	"Pie Chart","Bar Chart","Area Chart","Line Chart","Bubble chart","Animate Chart");
}

private <T>void addMenuItems(List<T> list,T...args) {
Collections.addAll(list,args);
}

private void addActionsMenuItemsUserData() {
	addMenuItems(actionsMenu.get().userDataProperty().get(),1,2,3,4);
}

private void addChartsMenuItemsUserData() {
	addMenuItems(chartsMenu.get().userDataProperty().get(),1,2,3,4,5,6);
}
}
