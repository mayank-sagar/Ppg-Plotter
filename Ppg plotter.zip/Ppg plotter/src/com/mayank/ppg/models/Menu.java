package com.mayank.ppg.models;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Menu {
private StringProperty menuName;
private ObjectProperty<ObservableList<String>> menuItems;
private ObjectProperty<ObservableList<Integer>> userData;

public Menu(String menuName) {
setMenuName(menuName);
}

public ObjectProperty<ObservableList<Integer>> userDataProperty() {
	if(userData == null) {
		userData = new SimpleObjectProperty<ObservableList<Integer>>(FXCollections.observableArrayList());
	}
	return userData;
} 

public void setUserData(ObservableList<Integer> userData) {
	userDataProperty().set(userData);
}

public ObservableList<Integer> getUserData() {
	return userData == null ?null:userData.get();
}

public StringProperty menuNameProperty() {
	if(menuName == null)
		menuName = new SimpleStringProperty();
	return menuName;
}


public void setMenuName(String name) {
	menuNameProperty().set(name);
}

public String getMenuName() {
	return menuName == null?null:menuName.get();
}

public ObjectProperty<ObservableList<String>> menuItemsProperty() {
	if(menuItems == null) 
		menuItems = new SimpleObjectProperty<ObservableList<String>>(FXCollections.observableArrayList());
	return menuItems;
}

public void setMenuItems(ObservableList<String> items) {
	menuItemsProperty().set(items);
}

public ObservableList<String> getMenuItems() {
	return menuItems == null?null:menuItems.get();
}
}
