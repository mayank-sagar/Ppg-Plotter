package com.mayank.ppg.models;

import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class PpgNotepadLab {
 private static PpgNotepadLab pnl ;
 private ObjectProperty<ObservableList<PpgNotepad>> ppgNotepads;
 
private static String[] months = {"Jan","Feb","Mar","April","May","June","July","Augest","Sep","Oct","Nov","Dec"};
private static String[] weeks = {"Sun","Mon","tue","wed","thus","fri","sat"};
 
 private PpgNotepadLab() {
	 ppgNotepads = new SimpleObjectProperty<ObservableList<PpgNotepad>>
	 (FXCollections.observableArrayList());
 }
 
 public static PpgNotepadLab getInstance() {
	 if(pnl == null ) pnl = new PpgNotepadLab();
 return pnl;
 }

 public  ObjectProperty<ObservableList<PpgNotepad>> ppgNotepadsProperty() {
	 return ppgNotepads;
 }
 
 
 public void setPpgNotepads(ObservableList<PpgNotepad> notepads) {
	 ppgNotepadsProperty().set(notepads);
 }
 
 public int ppgNotepadsSize() {
	 return ppgNotepadsProperty().get().size();
 }
 public ObservableList<PpgNotepad> getPpgNotepads() {
	 return ppgNotepads.get();
 }
 
 public void addPpgNotpad(PpgNotepad notepad) {
	 ppgNotepadsProperty().get().add(notepad);
 }
 
 
 public PpgNotepad getPpgNotepad(int i) {
     if(isIndexNotValid(i)) return null;
	 return ppgNotepadsProperty().get().get(i);
 }

 public PpgNotepad getPpgNotepadById(UUID id) {
	 for(PpgNotepad notepad:ppgNotepads.get()) {
		 if(notepad.getId().equals(id)) return notepad;
	 }
		 return  null;
 }
 
 
 public void removePpgNotepad(int i) {
	 if(isIndexNotValid(i)) return;
	 ppgNotepadsProperty().get().remove(i);
 }
 
 private boolean isIndexNotValid(int i) {return i < 0 || i >= 	 ppgNotepadsProperty().get().size();}

 
public String getDateAsString(UUID uuid) {
	for(PpgNotepad pads:ppgNotepadsProperty().get()) {
	 if( pads.getId().equals(uuid)) {
		 return getDateAsString(pads.getDate());
	 }
	}
	return null;
}

public static String getDateAsString(Date date) {
	Calendar calendar = Calendar.getInstance();
	calendar.setTime(date);
	String m = months[(calendar.get(Calendar.MONTH))];
    String week = weeks[(calendar.get(Calendar.WEEK_OF_MONTH))];
    String d = ""+calendar.get(Calendar.DATE);
    String year = ""+calendar.get(Calendar.YEAR);
    String hours = ""+calendar.get(Calendar.HOUR);
    String minutes = ""+calendar.get(Calendar.MINUTE);
    String sec = ""+calendar.get(Calendar.SECOND);
    String am_pm = +calendar.get(Calendar.AM_PM)==Calendar.AM?"AM":"PM";
   return (week+"/"+m+"/"+d+"/"+year+"  "+hours+":"+minutes+":"+sec+" "+am_pm).
		   toUpperCase();
}
} 
