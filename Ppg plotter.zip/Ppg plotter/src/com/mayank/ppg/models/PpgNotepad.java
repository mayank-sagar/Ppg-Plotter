package com.mayank.ppg.models;

import java.util.Date;
import java.util.Random;
import java.util.UUID;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;

public class PpgNotepad {
private ObjectProperty<UUID> id;
private ObjectProperty<ObservableList<Integer>> data;
private ObjectProperty<Date> date;
private StringProperty name;

private  String default_name = "ppg data"+
new Random(System.currentTimeMillis()).nextInt();

public PpgNotepad() {
	idProperty().set(UUID.randomUUID());
	dateProperty().set(new Date());
}


public PpgNotepad(Date date) {
    this();
	if(isDateEquallToNull(date)) return;
	dateProperty().set(date);
}

public PpgNotepad(ObservableList<Integer> data,Date date) {
	this(date);
	if(isDataEquallToNull(data)) return;
	dataProperty().set(data);
}

public PpgNotepad(ObservableList<Integer> data,Date date,String name) {
	this(date);
	if(isDataEquallToNull(data)) return;
	dataProperty().set(data);
	setName(name);
}


public PpgNotepad(UUID id,ObservableList<Integer> data,Date date,String name) {
	this(data,date,name);
	idProperty().set(id);
}

public PpgNotepad(String name) {
	this();
	setName(name);
}

public ObjectProperty<UUID >idProperty() {
	if(id == null) id = new SimpleObjectProperty<UUID>();
	return id;
}

public ObjectProperty<ObservableList<Integer>> dataProperty() {
	if(data == null) {
		data = new SimpleObjectProperty<ObservableList<Integer>>(FXCollections.observableArrayList());
	}
	return data;
}

public ObjectProperty<Date> dateProperty() {
	if(date == null) date = new SimpleObjectProperty<Date>();
	return date;
}

public UUID getId() {
	return id == null?null:idProperty().get();
}

public void setId(UUID id) {
	idProperty().set(id);
}

public ObservableList<Integer> getData() {
	return data == null?null:dataProperty().get();
}

public void setData(ObservableList<Integer> data) {
	dataProperty().set(data);
}

public Date getDate() {
	return date == null?null:dateProperty().get();
}

public void setDate(Date date) {
	dateProperty().set(date);
}

public StringProperty nameProperty() {
	if(name == null) {
		name = new SimpleStringProperty(default_name);
	}
	return name;
}

public String getName() {
	return  name == null?default_name:nameProperty().get();
}

public void setName(String n) {
	if(name == null) default_name = n;
	else nameProperty().set(default_name);
}
private boolean isDataEquallToNull(ObservableList<Integer> data) {return data == null;}
private boolean isDateEquallToNull(Date date) {return date == null;}

}
