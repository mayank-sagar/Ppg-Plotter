package com.mayank.ppg.interfaces;

import java.util.UUID;

import com.mayank.ppg.enumrations.Charts;

import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.scene.chart.XYChart;

public interface Chain {

	public void setNextInChain(Chain chain);
    public ObservableList<?> startProcess(Charts chart,ObservableMap<UUID,ObservableList<Integer>> observer);
}

