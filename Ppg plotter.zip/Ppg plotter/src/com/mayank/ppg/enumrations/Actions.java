package com.mayank.ppg.enumrations;

public enum Actions {
INSERT,REMOVE,ALTER
}
