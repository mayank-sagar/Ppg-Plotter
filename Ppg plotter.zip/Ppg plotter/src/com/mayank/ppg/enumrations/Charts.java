package com.mayank.ppg.enumrations;

public enum Charts {
	pieChart,barChart,areaChart,lineChart,bubbleChart,animateChart;
}
