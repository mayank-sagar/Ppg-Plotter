package com.mayank.ppg.view;

import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ListCell;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class PpgDataListCell extends ListCell<Integer>{
	
	protected void updateItem(Integer item,boolean empty) {
	super.updateItem(item, empty);
	updateView();
	}
	
	private void updateView() {
		setGraphic(null);
		setContentDisplay(ContentDisplay.LEFT);
		if(getItem() != null) {
			if(this.isEditing()) {
			TextField insertPpgField = new TextField(getItem().toString());
			Button delButton = new Button("Delete");
			Button alterButton = new Button("Alter");
			delButton.setOnMouseEntered(e -> {
				delButton.setScaleX(1.3);
				delButton.setScaleY(1.3);
			});
			delButton.setOnMouseExited(e -> {
				delButton.setScaleX(1);
				delButton.setScaleY(1);});
			
			alterButton.setOnMouseEntered(e -> {
				alterButton.setScaleX(1.3);
				alterButton.setScaleY(1.3);
				});
			alterButton.setOnMouseExited(e -> {
				alterButton.setScaleX(1);
				alterButton.setScaleY(1);});
			
			alterButton.setOnAction(e -> commitEdit(textToInt(insertPpgField.getText())));
			delButton.setOnAction(e -> getListView().getItems().remove(getIndex()));
			 HBox mainLayout  = new HBox(6,insertPpgField,alterButton,delButton);
			setGraphic(mainLayout);
			
			}
			else {
				Text text = new Text(getItem().toString());
				text.setFont(new Font(15));
			Circle circle = new Circle(10,10,text.getText().length() * 4,Color.LIGHTSLATEGRAY);
			StackPane pane  = new StackPane(circle,text);
			setGraphic(pane);
			setContentDisplay(ContentDisplay.CENTER);
			}
		}	
	}
	
	public void startEdit() {
		super.startEdit();
		updateView();
	}
	
	private Integer textToInt(String textValue) {
	    try {
		return new Integer(textValue);
	    }catch(NumberFormatException exp) {return getItem();}
	}
}
