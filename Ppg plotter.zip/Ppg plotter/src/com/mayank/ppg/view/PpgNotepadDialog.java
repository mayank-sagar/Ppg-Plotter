package com.mayank.ppg.view;


import com.mayank.ppg.control.ppgPlotterController;
import com.mayank.ppg.manager.PpgChartManager;
import com.mayank.ppg.manager.PpgClassifiedChartManager;
import com.mayank.ppg.models.PpgNotepad;
import com.mayank.ppg.models.PpgNotepadLab;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.effect.Reflection;
import javafx.scene.effect.SepiaTone;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.util.StringConverter;

public class PpgNotepadDialog {
    
	private PpgNotepad ppgNotepad;
	
	
	private ListView<Integer> dataList;
	private TextField enteryField;
	private ToggleButton ploatButton;
	private Label dateLabel;
	private Stage ppgNotepadStage;
	private ToggleButton ploatClassifiedButton;

	
	private ToggleGroup tg;
	private final int WIDTH = 550;
	private final int HEIGHT = 600;
	
	public PpgNotepadDialog(Stage parent) throws IllegalArgumentException{
	throwErrorNullParent(parent);
	initalizeAddNotepad();
	initalizeControls();
	setupControls();
    Scene scene = createGui();
    setupStageLaunchDialog(parent,scene);
	}
	
	
	private void throwErrorNullParent(Stage parent) {
		if(parent == null) throw new IllegalArgumentException();
	}
	
	private void setupStageLaunchDialog(Stage parent,Scene scene){
		ppgNotepadStage.setScene(scene);
		ppgNotepadStage.initOwner(parent);
		ppgNotepadStage.setWidth(WIDTH);
		ppgNotepadStage.setHeight(HEIGHT);
		ppgNotepadStage.show();
	}
	
	private void initalizeControls() {
		dataList = new ListView<Integer>(); 
		enteryField = new TextField();
		ploatButton = new ToggleButton();
		dateLabel = new Label();
		ploatClassifiedButton = new ToggleButton();
		ppgNotepadStage = new Stage();
		tg = new ToggleGroup();
	}
	
	private void setupControls() {
		setupDataList();
		setupEnteryField();
		setupPloatButton();
        setupShowClassifiedButton();
		setupDataLabel();
		setupPpgNotepadStage();
	}
	
	private void setupShowClassifiedButton() {
		ploatClassifiedButton.setText("Ploat Classfied");
		ploatClassifiedButton.setToggleGroup(tg);
		Reflection reflection = new Reflection();
		SepiaTone sephiaTone = new SepiaTone();
		reflection.setInput(sephiaTone);
		ploatClassifiedButton.setEffect(reflection);
		ploatClassifiedButton.selectedProperty().addListener(e -> registerUnregisterClassifiedData());
		}
	
	
	
	private void registerUnregisterClassifiedData() {
		if(ploatClassifiedButton.isSelected()) PpgClassifiedChartManager
		.getInstance().ploatClassified(ppgNotepad.getId(),ppgNotepad.getData());
		else  unploatClassifiedData();	
	}

	private void unploatClassifiedData() {
		PpgClassifiedChartManager.getInstance().unploatClassified(ppgNotepad.getId());
	}
	
	private void setupDataList() {
		dataList.setItems(ppgNotepad.dataProperty().get());
		dataList.cellFactoryProperty().set(e -> new PpgDataListCell());
	    dataList.setEditable(true);
	}
	
	private void setupPpgNotepadStage() {
		ppgNotepadStage.setOnCloseRequest(e -> unploatData());
	}
	
	private void setupEnteryField() {
		enteryField.setPromptText("Enter data you want to add");
		enteryField.setOnAction(e -> { 
			Integer i = convertTextToInt(enteryField.getText());
			if(i == null) return;
			ppgNotepad.dataProperty().get().add(i);
			enteryField.clear();
			});
		
	}
	
	private void setupPloatButton() {
	ploatButton.setText("Ploat");
	ploatButton.setToggleGroup(tg);
	Reflection mixEffect = new Reflection();
	mixEffect.setInput(new SepiaTone());
	ploatButton.setEffect(mixEffect);
	ploatButton.selectedProperty().addListener(e ->  registerUnregisterData());
	}
	
	private void registerUnregisterData() {
		if(ploatButton.isSelected()) PpgChartManager.getInstance(null).ploat(ppgNotepad.getId(),ppgNotepad.getData());
		else  unploatData();	
	}
   
    
    private void showErrorDialog() {
		new PpgErrorDialog("No Classification Found ",ppgNotepadStage);
	}
	
	private void unploatData() {
		PpgChartManager.getInstance(null).unploat(ppgNotepad.getId());
	}
	
	private  void setupDataLabel() {
		dateLabel.setText(PpgNotepadLab.getInstance().getDateAsString(ppgNotepad.getId()));
		dateLabel.setStyle("-fx-stroke-width:5;"+
		                    "-fx-stroke:blue"+
				           "-fx-text-size:20;");
		dateLabel.setOnMouseEntered(e -> {
			dateLabel.setScaleX(2);
			dateLabel.setScaleY(2);});
		dateLabel.setOnMouseExited(e -> {
			dateLabel.setScaleX(1);
			dateLabel.setScaleY(1);});
	}
	
	private Scene createGui() {
	HBox subLayout = new HBox(7,enteryField,ploatButton,ploatClassifiedButton); 
	VBox mainLayout = new VBox(10,dateLabel,dataList,subLayout);
	mainLayout.setPadding(new Insets(20));
	Scene scene = new Scene(mainLayout);
	mainLayout.setAlignment(Pos.CENTER);
	subLayout.setAlignment(Pos.CENTER);
	return scene;
	}
	
    private Integer convertTextToInt(String value) {
		try {
			return new Integer(value);
		}catch(NumberFormatException exp) {return null;}
	}
	
    
	private void initalizeAddNotepad() {
		ppgNotepad  = PpgNotepadLab.getInstance().
				getPpgNotepad(PpgNotepadLab.getInstance().ppgNotepadsSize()-1);
	}

	

}
