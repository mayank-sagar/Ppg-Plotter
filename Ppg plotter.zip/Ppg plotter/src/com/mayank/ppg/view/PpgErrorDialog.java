package com.mayank.ppg.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PpgErrorDialog {

	Stage stage;
	public PpgErrorDialog(String errorMsg,Stage pStage) {
		initStage(pStage);
		 Scene scene = createGui(errorMsg);
		 setupStageLaunchDialog(scene);
	}
	
	private void setupStageLaunchDialog(Scene scene) {
		stage.setScene(scene);
		stage.show();
	}
	private void initStage(Stage pStage) {
		stage = new Stage();
		stage.initOwner(pStage);
	}
	private Scene createGui(String errorMsg) {
		VBox vbox = new VBox(10,new Label(errorMsg),createOkButton());
		vbox.setAlignment(Pos.CENTER);
		vbox.setPadding(new Insets(10));
		return new Scene(vbox);
	}
	
	private Button createOkButton() {
		Button okButton = new Button("ok");
		okButton.setOnAction(e -> stage.close());
		return okButton;
	}
}
