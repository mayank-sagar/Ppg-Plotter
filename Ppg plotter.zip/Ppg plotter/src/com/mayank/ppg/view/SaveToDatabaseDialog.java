package com.mayank.ppg.view;

import com.mayank.ppg.models.PpgNotepad;
import com.mayank.ppg.models.PpgNotepadLab;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SaveToDatabaseDialog {
	
	private ListView<String> ppgNotepadsList;
	private Button saveButton;
	private Stage saveToDatabaseStage; 

public SaveToDatabaseDialog(Stage stage) {
	initControls();
	setupControls(stage);
	Scene scene = createGui();
	setupStageLaunchDialog(scene);
}



private void setupStageLaunchDialog(Scene scene) {
	saveToDatabaseStage.setScene(scene);
	saveToDatabaseStage.show();
}

private Scene createGui() {
	VBox box = new VBox(12,ppgNotepadsList,saveButton);
	box.setPadding(new Insets(20));
	return new Scene(box);
}

private void initControls() {
	ppgNotepadsList = new ListView<String>();
	saveButton = new Button();
	saveToDatabaseStage = new Stage();
}

private void setupControls(Stage stage) {
	setupPpgNotepadsList();
	setupSaveButton();
	setupSaveToDatabaseStage(stage);
}

private void setupSaveToDatabaseStage(Stage parent) {
	saveToDatabaseStage.initOwner(parent);
}

private void setupPpgNotepadsList() {
	ppgNotepadsList.setItems(getNotepadsName());
	ppgNotepadsList.selectionModelProperty().get().setSelectionMode(SelectionMode.MULTIPLE);
	// add to the database here
	ppgNotepadsList.getSelectionModel().selectedIndexProperty().addListener(e -> {});
}

private void setupSaveButton() {
	saveButton.setText("Save to database");
}

private ObservableList<String> getNotepadsName() {
	ObservableList<String> names = FXCollections.observableArrayList();
	for(PpgNotepad notepads:PpgNotepadLab.getInstance().getPpgNotepads()) {
		names.add(notepads.getName());
	}
	return names;
}
}
