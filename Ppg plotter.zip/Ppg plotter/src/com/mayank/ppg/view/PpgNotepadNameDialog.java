package com.mayank.ppg.view;

import com.mayank.ppg.models.PpgNotepad;
import com.mayank.ppg.models.PpgNotepadLab;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class PpgNotepadNameDialog {

	private Button okButton;
	private TextField nameField;
	private Stage notepadNameStage;
	private Stage mainStage;
	
	public PpgNotepadNameDialog(Stage parent) {
		throwErrorNullParent(parent);
		initilizeControl(parent);
		setupControls();
		setupListeners();
		Scene scene = createGUI();
		setupStageLaunchDialog(parent,scene);
	}
	
	
	
	private void setupStageLaunchDialog(Stage parent,Scene scene) {
		notepadNameStage.initOwner(parent);
		notepadNameStage.setScene(scene);
		notepadNameStage.show();
	}
	
	private void throwErrorNullParent(Stage parent) {
		if(parent == null) throw new IllegalArgumentException();
	}
	
	
	private void setupListeners() {
		setupOkButtonListeners();
		setupNameFieldListener();
	}
	
	private void setupOkButtonListeners() {
		okButton.setOnAction(e -> {
			createNewNotepad();
		});
	}
	
	private void setupNameFieldListener() {
		nameField.setOnAction(e -> {createNewNotepad();});
	}
	
	
	private void createNewNotepad() {
		PpgNotepadLab.getInstance().
		addPpgNotpad(new PpgNotepad(nameField.getText()));
		notepadNameStage.close();
	    new PpgNotepadDialog(mainStage);
	}
	
	private Scene createGUI() {
		HBox mainLayout = new HBox(7,okButton,nameField);
		mainLayout.setPadding(new Insets(15));
		return new Scene(mainLayout);
	}
	
	private void initilizeControl(Stage stage) {
		okButton = new Button();
		nameField = new TextField();
		notepadNameStage = new Stage();
		mainStage = stage;
	}

	private void setupControls() {
		setupOkButton();
		setupNameField();
	}
	
	private void setupOkButton() {
		okButton.setText("ok");
		okButton.setDefaultButton(true);
	}
	
	private void setupNameField() {
		nameField.setPromptText("insert name");
	}
}
