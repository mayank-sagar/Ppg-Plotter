package com.mayank.ppg.view;

public class ExtractFromDatabaseDialog {

}
