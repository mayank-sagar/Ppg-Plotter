package com.mayank.ppg.view;

import com.mayank.ppg.control.ppgPlotterController;
import com.mayank.ppg.manager.PpgChartManager;
import com.mayank.ppg.manager.PpgClassifiedChartManager;
import com.mayank.ppg.models.PpgPlotter;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.chart.Chart;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MainWindow extends Application{
    private PpgPlotter plotter;
	private ppgPlotterController pcc;
	private ToggleGroup tg;
	
	private BorderPane mainPane;
	private ScrollPane chartPane;
    private MenuBar menubar;
	private final int WIDTH = 600;
	private final int HEIGHT = 700;
	
	public void init() {
		plotter = new PpgPlotter();
		tg = new ToggleGroup();
	}
	
	public void start(Stage stage) {
		initilizeControls(stage);
		setupControls();
		setupListeners();
		setupPieChart();
	  setupAndLaunchScene(createGui(),stage);
	}
	
	
	private Scene createGui() {
		   mainPane.setTop(menubar);
		   mainPane.setCenter(chartPane);
		   return new Scene(mainPane);
	}
	

	private void setupPieChart()  {
		((RadioMenuItem)menubar.getMenus()
		.get(1).getItems().get(0)).selectedProperty().set(true);
	}
	
	private void setupListeners() {
		addChartPropertyListener();
		addClassifiedChartProperty();
	}
	
	private void addChartPropertyListener() {
		PpgChartManager.
		   getInstance(tg).
		   currentChartProperty().
		   addListener(e -> {
			   if(PpgChartManager.getInstance(tg).isChartEmpty()) {
				   ploatClassificationChart();
				   return;
			   }
			  ploatDataChart();
			   });
	}
	
	private void addClassifiedChartProperty() {
		PpgClassifiedChartManager.getInstance().classifiedChartPropperty().addListener(
				e ->		{ PieChart piecrt = PpgClassifiedChartManager.
				           getInstance().classifiedChartPropperty().get();
				            
				if(piecrt != null &&piecrt.getData().isEmpty()) {ploatDataChart();return;}
		        ploatClassificationChart();
		        }
				);
	}
	
	private void ploatDataChart() {
		mainPane.setCenter( PpgChartManager.
				   getInstance(tg).
				   currentChartProperty().get());   
				
	}
	
	
	private void ploatClassificationChart() {
		 mainPane.setCenter(PpgClassifiedChartManager.
					getInstance().classifiedChartPropperty().get());
	}
	private void initilizeControls(Stage stage) {
		mainPane = new BorderPane();
		chartPane = new ScrollPane();
		menubar = new MenuBar();
		pcc = new ppgPlotterController(stage);
	}
	
	private void setupControls() {
		setupMenubarControl();
	}
	
	private void setupMenubarControl() {
		menubar.getMenus().addAll(getActionsMenu(),getChartsMenu());
	}
	public static void main(String args[]) {
		launch(args);
	}
	
	
	private void setupAndLaunchScene(Scene scene,Stage stage) {
		stage.setScene(scene);
		stage.setWidth(WIDTH);
		stage.setHeight(HEIGHT);
		stage.show();
	}
	
	
	private Menu getActionsMenu() {
		Menu actionMenu = new Menu(plotter.getActionsMenu().getMenuName());
		ObservableList<String> nameList = plotter.getActionsMenu().getMenuItems();
		ObservableList<Integer> userData = plotter.getActionsMenu().getUserData();
		for(int i = 0;i < nameList.size();i++)  {
			MenuItem mi = new MenuItem(nameList.get(i));
			 setupActionMenuItemsListeners(mi,nameList,i); 
			mi.setUserData(userData.get(i));
			actionMenu.getItems().add(mi);
		}
		return actionMenu;
	}

	private void setupActionMenuItemsListeners(MenuItem mi,ObservableList<String> nameList,int index) {
		if(nameList.get(index).equals(nameList.get(0))) {
			mi.setOnAction(pcc.newPlotControl());
		}else if(nameList.get(index).equals(nameList.get(1)))
			mi.setOnAction(pcc.importPpgControl());
		else if(nameList.get(index).equals(nameList.get(2)))
			mi.setOnAction(pcc.saveToDbseControl());
		else if(nameList.get(index).equals(nameList.get(3)))
			mi.setOnAction(pcc.extFromDbseControl());
	}
	
	
	private Menu getChartsMenu() {
		Menu chartsMenu = new Menu(plotter.getChartsMenu().getMenuName());
		ObservableList<String> nameList = plotter.getChartsMenu().getMenuItems();
		ObservableList<Integer> userData = plotter.getChartsMenu().getUserData();
		for(int i = 0;i < nameList.size();i++)  { 
			RadioMenuItem rmi = new RadioMenuItem(nameList.get(i));
			rmi.setToggleGroup(tg);
			rmi.setUserData(userData.get(i));
			chartsMenu.getItems().add(rmi);
			if(userData.get(i) == 1) rmi.selectedProperty().set(true);
		}
		return chartsMenu;
	}


}


