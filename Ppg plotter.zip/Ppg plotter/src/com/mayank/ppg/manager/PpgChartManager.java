package com.mayank.ppg.manager;

import java.util.Collections;
import java.util.UUID;

import com.mayank.ppg.enumrations.Charts;
import com.mayank.ppg.models.ChartCreateFactory;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.concurrent.Task;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.BubbleChart;
import javafx.scene.chart.Chart;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;

public class PpgChartManager implements InvalidationListener{

	private ObservableMap<UUID,ObservableList<Integer>> ppgMap;
	private static PpgChartManager pcrtManager;
	private ObjectProperty<Toggle> selectedToggle;
	private ObjectProperty<Chart> currentChart;
	private PpgDataManager ppgDataMaanger; 
	private DoubleProperty animationHandler;
	
	private PpgChartManager(ToggleGroup tg) {
		ppgMap  = FXCollections.observableHashMap();
		ppgMap.addListener(this);
		selectedToggleProperty().bind(tg.selectedToggleProperty());
		selectedToggleProperty().addListener(this);
		ppgDataMaanger  = PpgDataManager.getInstance();
	}
	
	public static PpgChartManager getInstance(ToggleGroup tg) {
		if(pcrtManager == null) {
			pcrtManager = new PpgChartManager(tg);
		}
		return pcrtManager;
	}
	
	
	public boolean isChartEmpty(){return ppgMap.isEmpty();}
	
	public void ploat(UUID uuid,ObservableList<Integer> data) {
		if(data == null ) return ;
		ppgMap.put(uuid,data);
		data.addListener(this);
	}
	
	public void unploat(UUID uuid) {
		if(!ppgMap.containsKey(uuid)) return ;
		ppgMap.get(uuid).removeListener(this);
		ppgMap.remove(uuid);
	}
	
	public ObjectProperty<Chart> currentChartProperty() {
		if(currentChart == null)
			currentChart = new SimpleObjectProperty<Chart>();
		return currentChart;
	}
	
	
	private void setCurrentChartData(ObservableList data) {
		if(currentChartProperty().get() instanceof LineChart<?,?>)
		((LineChart<Number,Number>)currentChartProperty().get()).setData(data);		
		else if(currentChartProperty().get() instanceof PieChart){
			((PieChart)currentChartProperty().get()).setData(data);
		}else if(currentChartProperty().get() instanceof AreaChart<?,?>) {
			((AreaChart<Number,Number>)currentChartProperty().get()).setData(data);
		}else if(currentChartProperty().get() instanceof BarChart<?,?>) {
			((BarChart<String,Number>)currentChartProperty().get()).setData(data);
		}else if(currentChartProperty().get() instanceof BubbleChart<?,?>) {
			((BubbleChart<Number,Number>)currentChartProperty().get()).setData(data);
		}
	}
	
	public ObjectProperty<Toggle> selectedToggleProperty() {
 if(selectedToggle == null)  {
	 selectedToggle = new SimpleObjectProperty<Toggle>();
 }
 return selectedToggle;
}
	
	// use ppgDataMaanger to get the data
	
	@Override
	public void invalidated(Observable o) {
		refreshChartProperty();
	}	
	
	// compute the max y can go in he graph
	
	private int computeUpperBound() {
		int max = Collections.max(ppgMap.get(ppgMap.keySet().iterator().next()));
		for(UUID uuid:ppgMap.keySet()) {
		int min = Collections.max(ppgMap.get(uuid));
		if(max < min) {
			max = min;
		}}
		System.out.println(max);
	return max;	
		}
	
	private void refreshChartProperty()  {
      
		if(selectedToggle.get() == null) return ;
		
		switch(((Integer)selectedToggle
				.get()
				.getUserData())
				.intValue()) {	
		case 4:
			if(setPpgMapToNull()) break;
			currentChartProperty().set(ChartCreateFactory.createChart(1,computeUpperBound(),Charts.lineChart));
			setCurrentChartData(getPpgData(Charts.lineChart));
			break;
		case 1:
			if(setPpgMapToNull()) break;
			currentChartProperty().set(ChartCreateFactory.createChart(0,0,Charts.pieChart));
			((PieChart)currentChartProperty().get()).setData(PpgDataManager.getInstance().getData(Charts.pieChart,ppgMap));
		    break;
		case 3:
			if(setPpgMapToNull()) break;
			currentChartProperty().set(ChartCreateFactory.createChart(1,computeUpperBound(),Charts.areaChart));
			setCurrentChartData(getPpgData(Charts.areaChart));
		    break;
		case 2:
			if(setPpgMapToNull()) break;
			currentChartProperty().set(ChartCreateFactory.createChart(1,computeUpperBound(),Charts.barChart));
			setCurrentChartData(getPpgData(Charts.barChart));
			break;
		case 5:
			if(setPpgMapToNull()) break;
			currentChartProperty().set(ChartCreateFactory.createChart(1,computeUpperBound(),Charts.bubbleChart));
			setCurrentChartData(getPpgData(Charts.bubbleChart));
			break;
		}	
	}
	
	
	private boolean setPpgMapToNull() {
		if(ppgMap.keySet().size() == 0) { 
			setCurrentChartData(FXCollections.observableArrayList());
			return  true;
		}
		return false;
	}
	
	private ObservableList getPpgData(Charts chart) {
		return PpgDataManager.getInstance().getData(chart,ppgMap);
	}
		
}
