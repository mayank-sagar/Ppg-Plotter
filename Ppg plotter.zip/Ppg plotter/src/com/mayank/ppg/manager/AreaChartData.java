package com.mayank.ppg.manager;

import java.util.UUID;

import com.mayank.ppg.enumrations.Charts;
import com.mayank.ppg.interfaces.Chain;

import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;

public class AreaChartData implements Chain{
    
	private Chain nextInChain;
	@Override
	public void setNextInChain(Chain chain) {
		nextInChain = chain;
		
	}

	@Override
	public ObservableList<?> startProcess(Charts chart,ObservableMap<UUID,ObservableList<Integer>> observer) {
		return null;
	}

}
