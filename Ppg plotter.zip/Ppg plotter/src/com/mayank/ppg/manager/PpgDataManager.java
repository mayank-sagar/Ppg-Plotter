package com.mayank.ppg.manager;

import java.util.UUID;

import com.mayank.ppg.enumrations.Charts;
import com.mayank.ppg.interfaces.Chain;
import com.mayank.ppg.models.PpgNotepadLab;

import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
public class PpgDataManager {

	private Chain dataChain;
	private static PpgDataManager pdm;
	
	private PpgDataManager() {
		LineChartData  lda= new LineChartData();
		BarChartData bcd = new BarChartData();
    dataChain = new PieChartData();
    dataChain.setNextInChain(lda);
    lda.setNextInChain(bcd);
	}
	
	public static PpgDataManager getInstance() {
		if(pdm == null)
			pdm = new PpgDataManager();
		return pdm;
	}
	
	public ObservableList getData(Charts chart,ObservableMap<UUID,ObservableList<Integer>> observer) {
		return dataChain.startProcess(chart, observer);
	}
	
}
