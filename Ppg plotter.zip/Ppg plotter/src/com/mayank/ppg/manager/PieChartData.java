package com.mayank.ppg.manager;

import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

import com.mayank.ppg.enumrations.Charts;
import com.mayank.ppg.interfaces.Chain;
import com.mayank.ppg.models.PpgNotepad;
import com.mayank.ppg.models.PpgNotepadLab;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.scene.chart.PieChart;

public class PieChartData implements Chain {

	private Chain nextInChain;
	
	@Override
	public void setNextInChain(Chain chain) {
		nextInChain = chain;
	}

	@Override
	public ObservableList<?> startProcess(Charts chart,ObservableMap<UUID,ObservableList<Integer>> observer) {
     
		if(chart == Charts.pieChart) {
    	ObservableList<PieChart.Data> pieData =  FXCollections.observableArrayList(); 
		
    	Set<UUID> set = observer.keySet();
    	 for(UUID key:set) { 
    		 ObservableList<Integer> data = observer.get(key); 
    		 for(int i = 0; i < data.size();i++) {
    			 int value = data.get(i);
    			pieData.add(new PieChart.Data(PpgNotepadLab.getInstance().
    					 getPpgNotepadById(key).getName()+"("+value+")",value));
    			 
    		 }
    	 }
    	 return pieData;
     }else 
    	return  nextInChain.startProcess(chart, observer);
		
	}

}
