package com.mayank.ppg.manager;

import java.util.UUID;

import com.mayank.ppg.enumrations.Charts;
import com.mayank.ppg.interfaces.Chain;
import com.mayank.ppg.models.PpgNotepadLab;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.scene.chart.XYChart;

public class LineChartData implements Chain{

	private Chain nextInChain;
	@Override
	public void setNextInChain(Chain chain) {
		nextInChain = chain;
		
	}

	@Override
	public ObservableList<?> startProcess(Charts chart,ObservableMap<UUID,ObservableList<Integer>> observer) {
		if(chart == Charts.lineChart || chart == Charts.areaChart || chart == Charts.bubbleChart) {
			ObservableList<XYChart.Series<Number,Number>> serieses =  FXCollections.observableArrayList();
			for(UUID key:observer.keySet()) {
			XYChart.Series<Number,Number> series = new XYChart.Series<Number,Number>(); 
			series.setName(PpgNotepadLab.getInstance().getPpgNotepadById(key).getName());	
			int x  = 0;
			for(Integer value:observer.get(key)) {
				series.getData().add(new XYChart.Data<Number,Number>(++x,value));
			   System.out.println(value);
			  }	
				serieses.add(series);
			}
			return serieses;
		}else return  nextInChain.startProcess(chart, observer);
	}

}
