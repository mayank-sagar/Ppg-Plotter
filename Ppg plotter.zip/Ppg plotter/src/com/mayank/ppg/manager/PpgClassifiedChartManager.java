package com.mayank.ppg.manager;

import java.util.Set;
import java.util.UUID;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.scene.chart.PieChart;

public class PpgClassifiedChartManager implements InvalidationListener{

	private ObservableMap<UUID,ObservableList<Integer>> classifiedNotpadsData;
	private static PpgClassifiedChartManager pccm; 
	private ObjectProperty<PieChart> classifiedChart;
	private static final String CLASSIFICATION_CLASSNAME_1 = "Stress";
	private static final String CLASSIFICATION_CLASSNAME_2 = "Other";
	
	private PpgClassifiedChartManager() {
		classifiedNotpadsData = FXCollections.observableHashMap();
		classifiedNotpadsData.addListener(this);
		}
	
	
	public ObjectProperty<PieChart> classifiedChartPropperty() {
		if(classifiedChart == null) classifiedChart = new SimpleObjectProperty<PieChart>();
		return classifiedChart;
	}
	
	public void setClassifiedChart(PieChart pc) {
		classifiedChartPropperty().set(pc);
	}
	
	public PieChart getClassifiedChart() {
		return classifiedChart == null?null:classifiedChartPropperty().get();
	}
	
	public static PpgClassifiedChartManager getInstance() {
		if(pccm == null) {
			pccm = new PpgClassifiedChartManager();
		}
		return pccm;
	}
	
	public void ploatClassified(UUID uuid,ObservableList<Integer> cData) {
		if(uuid == null || cData == null) return;
		classifiedNotpadsData.put(uuid, cData);
	}
	
	
	
	private void refeshChart() {
		setClassifiedChart(createClassifiedPieChart());
	}
	
	
	public void unploatClassified(UUID uuid) {
		classifiedNotpadsData.remove(uuid);
	}
	
	private PieChart createClassifiedPieChart() {
		PieChart pieChart = new PieChart(getData());
		pieChart.setTitle("Classified Data");
		return pieChart;
	}
	
	
	private ObservableList<PieChart.Data> getData() {
 	ObservableList<PieChart.Data> pieData =  FXCollections.observableArrayList(); 
	int stress = 0,other = 0;	
	Set<UUID> set = classifiedNotpadsData.keySet();
    	 for(UUID key:set) { 
    		ObservableList<Integer> data = classifiedNotpadsData.get(key);
    		 
    		 for(int i = 0; i < data.size();i++) {
    			 int value = data.get(i);
    			 if(value <= 65)  stress++;
    			 else other++;
    		 }
    		 pieData.clear();
    		 pieData.add(new PieChart.Data(CLASSIFICATION_CLASSNAME_1,stress));
    		 pieData.add(new PieChart.Data(CLASSIFICATION_CLASSNAME_2,other));
    	 }
    	 
    	 return pieData;
	}


	@Override
	public void invalidated(Observable arg0) {
		refeshChart();
	}
	
}
