package com.mayank.ppg.control;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.mayank.ppg.database.SqliteConnector;
import com.mayank.ppg.manager.PpgChartManager;
import com.mayank.ppg.models.PpgNotepad;
import com.mayank.ppg.models.PpgNotepadLab;
import com.mayank.ppg.view.PpgNotepadDialog;
import com.mayank.ppg.view.PpgNotepadNameDialog;
import com.mayank.ppg.view.SaveToDatabaseDialog;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.ToggleGroup;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

public class ppgPlotterController {

	private EventHandler<ActionEvent> newPlotControl;
	private EventHandler<ActionEvent> importPpgControl;
	private EventHandler<ActionEvent> saveToDbseControl;
	private EventHandler<ActionEvent> extFromDbseControl;
	
	public ppgPlotterController(Stage stage) {
		newPlotControl = e -> {new PpgNotepadNameDialog(stage);}; 
		saveToDbseControl = e -> {SqliteConnector.dbConnect();};
		extFromDbseControl = e -> {};
		importPpgControl = e -> {
			FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().
            add(new ExtensionFilter("Ppg files","*.ppg"));
		    File file = fileChooser.showOpenDialog(stage);
		    if(file != null) {
		     PpgNotepadLab.getInstance().addPpgNotpad(new PpgNotepad(getDataFromFile(file),null,file.getName()));
		     new PpgNotepadDialog(stage);
		    }
		  };
	}
	
	
	public EventHandler<ActionEvent> saveToDbseControl() {
		return saveToDbseControl;
	}
	
	public EventHandler<ActionEvent> extFromDbseControl() {
	return extFromDbseControl;	
	}
	
	public EventHandler<ActionEvent> newPlotControl() {
		return newPlotControl;
	}
	
	public EventHandler<ActionEvent> importPpgControl() {
		return importPpgControl;
	}
	
	public void toggleGroupControl(ToggleGroup tg) {
		PpgChartManager.getInstance(tg);
	}
	
	private ObservableList<Integer> getDataFromFile(File file) {
		FileInputStream stream = null;
		ObservableList<Integer> data = FXCollections.observableArrayList();
		try {
		 stream = new FileInputStream(file);
		 int c;
		 Integer collect = 0;
		 Boolean flag = true;
		 while((c = stream.read()) != -1) {
			 
			 System.out.println(c);
			 if(isSpaceOrEnter(c)){
				 if(!flag) continue;
				 data.add(collect);
				 collect = resetCollect(0,'0');
                  flag = false;
			 } else {
			 collect = resetCollect(collect,c);
			 flag = true;
			 }
			 
		 }
		 data.add(collect);
	}catch(FileNotFoundException exp) {
		printError("error occured while importing file ",exp);
		return null;
	}catch(IOException exp){
		printError("i/o error occured while importing file ",exp);
		return null;
	}finally{
		try {
		if(stream != null)
		stream.close();
		}catch(IOException exp) {
			System.err.println("error accured while importing file "+exp);
			return null;	
		}
	}
		return  data;
	}
	
	private boolean isSpaceOrEnter(int c) {
		return c == '\r' || c == ' '  || c == '\n';
	} 
	
	private int resetCollect(int collect,int c) {
		return (collect * 10) + Character.getNumericValue(c);
	}
	private void printError(String error,Exception exp) {
		System.err.println(error+exp);
	}

   public static ObservableList<Integer> processClassifiedData(ObservableMap<String,Integer> classifiedClassData,ObservableList<Integer> ppgData) {
       ObservableList<Integer> pcd = FXCollections.observableArrayList();
       int maxData = 0;
       for(String key:classifiedClassData.keySet()) {
          int i  = 0;	
      	 for(Integer data:ppgData) {
      		 
      		 if(data <= classifiedClassData.get(key)) i++; 
      			 
      	 }
      	 pcd.add(i);
      	 if(pcd.size() == 1)
      	 maxData = i;
      	 else if(pcd.get(pcd.size()-1) > maxData) {
      		 maxData = pcd.size()-1;
      	 }
   }

        // make other name invalid to enter in the calssification 
       if(maxData != ppgData.size()) {
    	   if(classifiedClassData.containsKey("Other"))
    		   pcd.remove(pcd.size() - 1);
    	   else
    	   classifiedClassData.put("Other",-1);
    	   pcd.add(ppgData.size() - maxData);
       }else if(classifiedClassData.containsKey("Other")) {
    	   classifiedClassData.remove("Other",-1);
    	   pcd.remove(pcd.size() - 1);
       }
       
       return pcd;
}

}